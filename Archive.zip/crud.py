# crud.py
from fastapi.responses import JSONResponse
import mysql
from connections import create_connection
from datetime import datetime
import logging
# from your_db_file import create_connection   # adjust import

from datetime import datetime
from checkColumns import validate_api

def create_user(api: str, model_dict: dict):
    columns = list(model_dict.keys())
    table, safe_columns = validate_api(api, columns)
    if not safe_columns:
        raise ValueError("No valid columns provided for insertion.")
    values = [model_dict[col] for col in safe_columns]
    columns_str = ', '.join(f"`{col}`" for col in safe_columns)
    placeholders = ', '.join(['%s'] * len(safe_columns))
    query = f"INSERT INTO `{table}` ({columns_str}) VALUES ({placeholders})"
    conn = create_connection()
    try:
        with conn.cursor() as cursor:
            print(f"Executing query: {query} with values: {values}")
            cursor.execute(query, values)
        conn.commit()
    finally:
        conn.close()



def save_log(m_snd,m_reci,m_api,m_ip):
    conn = create_connection()
    cursor = conn.cursor()
    now = datetime.now()
    query = """INSERT INTO m_logs(m_snd,m_reci,m_api,m_ip) VALUES (%s,%s,%s,%s)"""
    cursor.execute(query, (m_snd,m_reci,m_api,m_ip))
    conn.commit()
    cursor.close()
    conn.close()

# READ
def read_specific_data(table, column, value):
    conn = create_connection()
    if conn is not None:
        try:
            cursor = conn.cursor(dictionary=True)  # Use dictionary=True to get results as dictionaries
            query = f"SELECT * FROM {table} WHERE {column} = %s"
            cursor.execute(query, (value,))
            users = cursor.fetchall()
            cursor.close()
            conn.close()
            return users
        except mysql.connector.Error as e:
            logging.error(f"Error reading users: {e}")
            return []
    return []

def read_users():
    conn = create_connection()
    if conn is not None:
        try:
            cursor = conn.cursor(dictionary=True)  # Use dictionary=True to get results as dictionaries
            cursor.execute("SELECT * FROM users")
            users = cursor.fetchall()
            cursor.close()
            conn.close()
            return users
        except mysql.connector.Error as e:
            print(f"Error reading users: {e}")
            return []
    return []

# UPDATE
def update_user_email(user_id, new_email):
    conn = create_connection()
    cursor = conn.cursor()
    query = "UPDATE users SET email = %s WHERE id = %s"
    cursor.execute(query, (new_email, user_id))
    conn.commit()
    logging.info("User updated.")
    cursor.close()
    conn.close()

# DELETE
def delete_user(user_id):
    conn = create_connection()
    cursor = conn.cursor()
    query = "DELETE FROM users WHERE id = %s"
    cursor.execute(query, (user_id,))
    conn.commit()
    logging.info("User deleted.")
    cursor.close()
    conn.close()
