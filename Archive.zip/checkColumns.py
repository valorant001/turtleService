# Mapping API actions to their target tables & allowed columns
api_columns = {
    "CREATEUSER": {
        "table": "users",
        "columns": {"name"}
    },
    "CREATELOG": {
        "table": "m_logs",
        "columns": {"m_snd", "m_reci", "m_api", "m_ip"}
    }
}

def validate_api(api: str, columns: list[str]):
    """Validate API action, table and columns"""
    if api not in api_columns:
        raise ValueError(f"Invalid API action: {api}")
    
    table_info = api_columns[api]
    table, allowed = table_info["table"], table_info["columns"]

    

    extra_columns = set(columns) - allowed
    if extra_columns:
        raise ValueError(f"Parameter(s) extra/not allowed: {extra_columns}")

    missing_col = allowed - set(columns)
    if missing_col:
        raise ValueError(f"Missing Parameter: {missing_col}")

    # Only return columns that are allowed
    safe_columns = [col for col in columns if col in allowed]

    return table, safe_columns
