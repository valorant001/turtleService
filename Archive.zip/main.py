# main.py
import json
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List
import crud
app = FastAPI()


class UserUpdate(BaseModel):
    id: int
    email: str

class InsertLog(BaseModel):
    data:str

from fastapi import FastAPI,Request
import json
from checkColumns import validate_api
import crud  # your create_user function
from usersModel import User

app = FastAPI()

@app.post("/users")
async def create_user_endpoint(request: Request):
    user_data = await request.json()  
    try:
        crud.create_user("CREATEUSER", user_data)  
        return user_data
    except Exception as e:
        return {"error": str(e)}
    except Exception as e:
        save_log(json.dumps({"error": str(e)}), "server", "USERCREATE", "127.0.0.1")
        return {"error": str(e)}


def save_log(mSend,mRecieve,mAPI,mIP):
        crud.save_log(mSend,mRecieve,mAPI,mIP)
        # return data

@app.get("/users")
# def get_users(user: GetSpecificUsers,table: tableName):
#         # Optional: whitelist table/column
#     # allowed_tables = ["users"]
#     # allowed_columns = ["id", "email", "phone"]

#     # if user.table not in allowed_tables or user.column not in allowed_columns:
#     # raise HTTPException(status_code=400, detail="Invalid table or column")

#     reun = crud.read_specific_data(table.user_Table_name,user.id,user.type)
#     if not reun:
#         raise HTTPException(
#             status_code=404,
#             detail=convertedResponse(404, "error", "User not found")
#         )
#     return convertedResponse(200, "success", reun)

@app.put("/users")
def update_user(user: UserUpdate):
    crud.update_user_email(user.id, user.email)
    return {"message": "User updated"}

# @app.delete("/users")
# def delete_user(user: UserID):
#     crud.delete_user(user.id)
#     return {"message": "User deleted"}
def convertedResponse(code,status,response):
    return {
        "code":code,
        "status":status,
        "response":response
    }